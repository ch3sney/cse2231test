import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.stack.Stack;
import components.stack.Stack1L;

/**
 * Implementation of setLengthOfLeftStack for Homework #7.
 *
 * @author Luke Chesney
 */
public final class Homework7 {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private Homework7() {
        // no code needed here
    }

    /**
     * Shifts entries between {@code leftStack} and {@code rightStack}, keeping
     * reverse of the former concatenated with the latter fixed, and resulting
     * in length of the former equal to {@code newLeftLength}.
     *
     * @param <T>
     *            type of {@code Stack} entries
     * @param leftStack
     *            the left {@code Stack}
     * @param rightStack
     *            the right {@code Stack}
     * @param newLeftLength
     *            desired new length of {@code leftStack}
     * @updates leftStack, rightStack
     * @requires <pre>
     * 0 <= newLeftLength  and
     * newLeftLength <= |leftStack| + |rightStack|
     * </pre>
     * @ensures <pre>
     * rev(leftStack) * rightStack = rev(#leftStack) * #rightStack  and
     * |leftStack| = newLeftLength}
     * </pre>
     */
    private static <T> void setLengthOfLeftStack(Stack<T> leftStack,
            Stack<T> rightStack, int newLeftLength) {
        if (leftStack.length() > newLeftLength) {
            while (leftStack.length() > newLeftLength) {
                T currElement = leftStack.pop();
                rightStack.push(currElement);
            }
        } else {
            while (leftStack.length() < newLeftLength) {
                T currElement = rightStack.pop();
                leftStack.push(currElement);
            }
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        // Just testing the method here...
        SimpleWriter out = new SimpleWriter1L();
        Stack<String> testStackL = new Stack1L<>();
        testStackL.push("blue");
        testStackL.push("green");
        testStackL.push("red");

        Stack<String> testStackR = new Stack1L<>();
        testStackR.push("squirrel");
        testStackR.push("dog");
        testStackR.push("cat");

        out.println("#leftStack = " + testStackL.toString());
        out.println("#rightStack = " + testStackR.toString());

        setLengthOfLeftStack(testStackL, testStackR, 2);

        out.println("\nleftStack = " + testStackL.toString());
        out.println("rightStack = " + testStackR.toString());

        out.close();
    }

}
